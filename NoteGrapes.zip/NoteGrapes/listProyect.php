<!DOCTYPE html>
<?php 
    require_once('phpFunc/conexion.php');
    require_once('phpFunc/verif.php');
    require_once('phpFunc/regis.php');
    session_start();

// + Verificar sesión iniciada    
    if(!isset($_SESSION['username']) || !isset($_SESSION['login'])){
        header('Location: index.html');
        exit();
    }
    $nom = $_SESSION['username'];

// +  Verificar acceso a la opcion

    $uId = $_SESSION['id'];
    $col = 'id';
    $ord = 'ASC';

    if(isset($_POST['eliminarProyecto'])){
        $pId = $_POST['idProyecto'];
        $resEP = eliminarProyecto($conect, $pId, $uId);
        if($resEP){
            echo "<script>alert('Proyecto eliminado');
             window.location.href = 'listProyect.php';</script>";
            exit();
        }else{
            echo "<script>alert('Error al eliminar el proyecto, intente de nuevo');
             window.location.href = 'listProyect.php';</script>";
            exit();
        }
    }
// + Encontrar proyectos
    $resO = obtenerProyectosUsuario($conect, $uId, $col, $ord);
    if(!$resO){

        $_SESSION['latestProyect'] = null;
        echo "<script>alert('No se tienen proyectos registrados.');
             window.location.href = 'menuPrin.php';</script>";
        exit();
    }
// + Encontrar proyecto reciente del usuario
    $resE = encontrarProyectoReciente($conect, $uId, "MAX(id)");
    if($resE){
        $_SESSION['latestProyect'] = $resE;
        $lpId = $_SESSION['latestProyect'];
    }else{
        //echo "<script>alert('No tienes proyectos creados.');</script>";
        $lpId = null;
        $_SESSION['latestProyect'] = $lpId;
    }

// + Cargar colores del proyecto
    $col = $_SESSION['color'];
?>

<html lang="es" class="<?php echo $col; ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/colors.css">
        <link rel="stylesheet" href="css/forms.css">
        <link rel="stylesheet" href="css/general.css">
        <link rel="stylesheet" href="css/design.css">
        <link rel="stylesheet" href="css/tablas.css">
        <script src= "jscript/buttonsAct.js"></script>
        <link rel="icon" type="image/png" sizes="32x32" href="images/icon1.png">
        <title>Mis Proyectos</title>
    </head>
    <section class="patUp">
        <script src="jscript/buttonColors.js" defer></script>
        <body class="bodyPrin">
            <main id="mainPrin">
                <section class="mainCont">
                    <aside class="mainAsid">
                        <div id="asidCont">
                            <section class="logoCuen">
                                <a href="menuPrin.php">
                                    <p class="logText">Ir al menu</p>
                                    <img src="images/regresar.png" alt="Cuenta"> 
                                </a>
                            </section>
                            <div class="lin">
                              <hr class="homHr">   
                            </div>
                            <section class="logoCuen">
                                <a href="optsUsuario.php">
                                    <p class="logText"><?php echo $nom; ?></p>
                                    <img src="images/Cuenta.png" alt="Cuenta">
                                </a>     
                            </section>
                                
                            <div class="lin">
                                <hr class="homHr">   
                            </div>

                            <?php if(isset($_SESSION['latestProyect']) && $_SESSION['latestProyect'] !== null){ ?>

                            
                            <section class="logoCuen">
                                <a href="contProyect.php?id=<?php echo $_SESSION['latestProyect']; ?>">
                                    <p class="logText">Proyecto reciente</p>
                                    <img src="images/ReciProyecto.png" alt="Cuenta"> 
                                </a>
                            </section>

                            <div class="lin">
                                <hr class="homHr">   
                            </div>
                            
                            <?php }?>

                            <section class="logoCuen">
                                <a href="crearProyect.php">
                                    <p class="logText">Crear Proyecto</p>
                                    <img src="images/CrearProyecto.png" alt="Cuenta"> 
                                </a>
                            </section>

                        </div>
                    </aside>
                    <section id="mainHH">
                        <section class="mainHom mainOpts">
                            <section class="contOpts optsTable">

                                <div class="hrLin">
                                    <hr> 
                                </div>

                                <section class="titlOpts">
                                   <h4>Mis Proyectos:</h4>  
                                </section>

                                <div class="hrLin">
                                    <hr> 
                                </div>
                                <section class="tableCont">
                                    <section id="contTable">
                                        <table>
                                            <thead>
                                                <tr>
                                                    <th class="titl">Titulo</th>
                                                    <th class="dscp">Descripción</th>
                                                    <th class="acts">Opciones</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while($fil = mysqli_fetch_assoc($resO)) { ?>
                                                <tr>
                                                    <td class="titl"><div class="casTd"><a href="contProyect.php?id=<?php echo $fil['id']; ?>"><?php echo htmlspecialchars($fil['titulo'], ENT_QUOTES, 'UTF-8'); ?></a></div></td>
                                                    <td class="dscp"><div class="casTd"><?php echo htmlspecialchars($fil['descripcion'], ENT_QUOTES, 'UTF-8'); ?></div></td>
                                                    <td class="acts"><div class="casTd"><a class="tdA" href="editProyect.php?id=<?php echo $fil['id']?>"><img src="images/Editar.png" alt="Editar"></a><form action="listProyect.php" method="post" onsubmit="return confirm('¿Seguro que desea eliminar este proyecto?');"><input type="hidden" name="idProyecto" value="<?php echo $fil['id']; ?>"><button class="tdA" type="submit" name="eliminarProyecto"><img src="images/Eliminar.png" alt="Eliminar"></button></form></div></td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </section>
                                </section>
                            </section>
                        </section>
                    </section>
                </section>
            </main>
        </body>
    </section>
</html>