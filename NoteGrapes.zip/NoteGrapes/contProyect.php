<!DOCTYPE html>
<?php 
    session_start();
    require_once('phpFunc/conexion.php');
    require_once('phpFunc/verif.php');
    require_once('phpFunc/camb.php');
    require_once('phpFunc/regis.php');

    //Zona horaria
    date_default_timezone_set("America/Mexico_City");  
    $fechAct = new DateTime();
    $act = date("Y-m-d");
    
// + Verificar sesión iniciada    
    if(!isset($_SESSION['username']) || !isset($_SESSION['login'])){
        header('Location: index.html');
        exit();
    }
    $uId = $_SESSION['id'];
    $nom = $_SESSION['username'];

// + Verificar id enviado
    if(!isset($_GET['id'])){
        if(empty($_SESSION['latestProyect'])){
            echo "<script>alert('No se encontró el proyecto.');
            window.location.href = 'menuPrin.php';</script>";
            exit();
        }
        $proyecto = $_SESSION['latestProyect'];
    }else{
        $proyecto = $_GET['id'];
    }
    $idB = "id";
    $_SESSION['latestProyect'] = $proyecto;

// + Cargar datos del proyecto (Titulo y Descripción)
    $resP = encontrarProyecto($idB, $proyecto, $conect);

    if(!$resP){
        echo "<script>alert('No se encontró el proyecto.');
            window.location.href = 'menuPrin.php';</script>";
        exit();
    }
    $tit = $resP['titulo'];
    $des = $resP['descripcion'];

// + Verificar si el proyecto pertenece al usuario
    $uId = $_SESSION['id'];
    $resV = verificarAdminProyecto($conect, $uId, $proyecto);
    if(!$resV){
        echo "<script>alert('No tienes permiso para editar este proyecto.');
        window.location.href = 'menuPrin.php';</script>";
    }


// + Guardar Cambios
    if(isset($_POST['guardarCambios'])){
            foreach($_POST['check'] as $check) {
                if($check['enabled'] === "true"){
                    if(isset($check['id'])){
                        if(isset($check['checked'])){
                            $val = 1;
                        }else{
                            $val = 0;
                        }
                        $chk = $check['id'];
                        $hom = $check['homework'];

                        $resAC = actualizarCheck($conect, $chk, $hom, $val);
                        if(!$resAC){
                            echo "<script>alert('Error al guardar los cambios.');
                            window.location.href = 'contProyect.php';</script>";
                            exit();
                        }
                    }
                }
            }
        echo "<script>window.location.href = 'contProyect.php';</script>";
        exit();
    }
// +  Eliminar tarea    
    if(isset($_POST['eliminarTarea'])){
        $id = $_POST['eliminarTarea'];
        $resE = elimTarea($conect, $id, $uId);
        if(!$resE){
            echo "<script>alert('Error al eliminar tarea.');
                window.location.href = 'contProyect.php';</script>";
            exit();
        }
    }
// + Cargar tareas del proyecto
    $col = 'id';
    $ord = 'ASC';
    $resO = obtenerTareasProyecto($conect, $proyecto, $col, $ord);
    if(!$resO){
        echo "<script>alert('No se tienen tareas registradas.');</script>";
    }

// + Cargar colores del proyecto
    $col = $_SESSION['color'];
?>
<html lang="es" class="<?php echo $col; ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/colors.css">
        <link rel="stylesheet" href="css/general.css">
        <link rel="stylesheet" href="css/forms.css">
        <link rel="stylesheet" href="css/design.css">
        
        <link rel="icon" type="image/png" sizes="32x32" href="images/icon1.png">
        <title><?php echo htmlspecialchars($tit, ENT_QUOTES, 'UTF-8'); ?></title>
    </head>
    <section class="patUp">
        <script src="jscript/buttonColors.js" defer></script>
        <body class="bodyPrin">
            <main id="mainPrin">
                <section class="mainCont">
                    
                        <aside class="mainAsid">

                            <div id="asidCont">
                                <section class="logoCuen">
                                    <a href="menuPrin.php">
                                        <p class="logText">Ir al menu</p>
                                        <img src="images/regresar.png" alt="Cuenta"> 
                                    </a>
                                </section>
                                <div class="lin">
                                <hr>   
                                </div>
                                <section class="logoCuen">
                                    <a href="optsUsuario.php">
                                        <p class="logText"><?php echo $nom; ?></p>
                                        <img src="images/Cuenta.png" alt="Cuenta">
                                    </a>     
                                </section>
                                <div class="lin">
                                <hr>   
                                </div>

                                <section class="logoCuen">
                                    <form id="formGuard" action="contProyect.php" method="post">
                                    <button type="submit" name="guardarCambios" style="background: none; border: none; cursor: pointer;">
                                        <p class="logText">Guardar Cambios</p>
                                        <img src="images/Guardar.png" alt="Cuenta"> 
                                    </button>
                                    </form>
                                </section>
                                
                                <div class="lin">
                                <hr>   
                                </div>
                                <section class="logoCuen">
                                    <a href="editProyect.php?id=<?php echo $proyecto; ?>">
                                        <p class="logText">Editar proyecto</p>
                                        <img src="images/ConfProyecto.png" alt="Cuenta"> 
                                    </a>
                                </section>
                                <div class="lin">
                                <hr>   
                                </div>
                                
                                <section class="logoCuen">
                                    <a href="listProyect.php">
                                        <p class="logText">Mis proyectos</p>
                                        <img src="images/Proyectos.png" alt="Cuenta"> 
                                    </a>
                                </section>
                                
                                <div class="lin">
                                <hr>   
                                </div>
                                
                                <section class="logoCuen">
                                    <a href="crearProyect.php">
                                        <p class="logText">Crear Proyecto</p>
                                        <img src="images/CrearProyecto.png" alt="Cuenta"> 
                                    </a>
                                </section> 
                            </div>

                        </aside>
                        <section id="mainHH">
                            <header id="mainHead">
                                <div id="headTitl">
                                    <h4><?php echo htmlspecialchars($tit, ENT_QUOTES, 'UTF-8'); ?></h4>
                                </div>
                                <div id="headDesc">
                                    <textarea disabled name="" id="desc"><?php echo htmlspecialchars($des, ENT_QUOTES, 'UTF-8'); ?></textarea>
                                </div>
                            </header>
                            <section class="mainHom">
                                <div class="cont">

                                    <?php while($fil = mysqli_fetch_assoc($resO)) { ?>
                                        <div class="homework">
                                            <div class="homCont">
                                                <div class="homFch">
                                                    <?php $fecha = $fil['fecha']; if ($fecha !== null && $fecha !== '0000-00-00' && $fecha !== '') {?>
                                                        <p class="fechText">Fecha de entrega: <b style="text-decoration: underline;"><?php echo htmlspecialchars($fil['fecha'], ENT_QUOTES, 'UTF-8'); ?></b></p>
                                                    <?php }?>
                                                </div>
                                                <div class="homTitle">
                                                    <h5><?php echo htmlspecialchars($fil['titulo'], ENT_QUOTES, 'UTF-8'); ?></h5>
                                                </div>
                                                <?php if (!empty(trim($fil['descripcion']))){?>
                                                <div class="homTitle">
                                                    <p class="fechText"><?php echo htmlspecialchars($fil['descripcion'], ENT_QUOTES, 'UTF-8'); ?></p>
                                                </div>
                                                <?php }?>
                                                <div class="homLines">
                                                    <hr>
                                                </div>
                                                <?php 
                                                    $tkId = $fil['id'];
                                                    $resOt = obtenerContenidoTarea($conect, $tkId);
                                                    if(!$resOt){
                                                        echo "<p class='fechText'>No se tiene contenido registrado.</p>";
                                                    }else{
                                                        $contAnt = '';
                                                        while($fil2 = mysqli_fetch_assoc($resOt)) {?>
                                                    <?php if($fil2['tipo'] === 'img') { ?>
                                                            <div class='homLines2'>
                                                                <hr>
                                                            </div>
                                                        <div class="homImg">  
                                                            <img class="homImages"src="<?php echo htmlspecialchars($fil2['contenido'], ENT_QUOTES, 'UTF-8'); ?>" alt="Imagen de la tarea">
                                                        </div>
                                                    <?php }else{ ?>
                                                        <?php if($fil2['orden'] > 0 && ($fil2['tipo'] === 'check' || ($fil2['tipo'] === 'description' && $contAnt === 'description'))) { echo "<div class='homLines2'><hr></div>";} ?>
                                                        <div class="homPoints">                                                       
                                                                <div class="homChb">
                                                                    <?php if ($fil2['tipo'] === 'check') { ?> 
<!--    
    check[id][checked]
    check[id][homework]
    check[id][id]
    check[id][enabled]
-->
                                                                        <?php if($fil2 === "000-00-00" || $fil['fecha'] >= $act){}?>
                                                                        <input type="checkbox"  class="chBox" form='formGuard'  <?php echo "name='check[". $fil2['id']."][checked]'     id='". $fil2['id'] ."'"?> <?php echo ($fil2['estado'] == 1) ? 'checked ' : ''; if($fil['fecha'] >= $act || $fil['fecha'] === "0000-00-00"){ echo "";}else{ echo "disabled";}?>> 
                                                                        <input type="hidden"    form="formGuard"                <?php echo "name='check[". $fil2['id']."][homework]'    value='".$fil['id']."'";?>>
                                                                        <input type="hidden"    form="formGuard"                <?php echo "name='check[". $fil2['id']."][id]'          value='".$fil2['id']."'";?>>
                                                                        <input type="hidden"    form="formGuard"                <?php echo "name='check[". $fil2['id']."][enabled]'";?> <?php if($fil['fecha'] >= $act || $fil['fecha'] === "0000-00-00"){ echo "value= 'true'";}else{ echo "value='false'";}?>>
                                                                        
                                                                    <?php } ?>        
                                                                </div>
                                                            <div class="homSp">
                                                                <?php if ($fil2['tipo'] === 'check') { ?>  
                                                                    <label class="noSelect" for="<?php echo $fil2['id']; ?>"> 
                                                                        <span class="homTxt" <?php echo ($fil2['estado'] == 1) ? "style='text-decoration:line-through;'" : ''; ?>><?php echo htmlspecialchars($fil2['contenido'], ENT_QUOTES, 'UTF-8'); ?> </span> 
                                                                    </label>
                                                                <?php } else if ($fil2['tipo'] === 'description') { ?>
                                                                    <span class="fechText"><?php echo htmlspecialchars($fil2['contenido'], ENT_QUOTES, 'UTF-8'); ?></span>
                                                                <?php }?>
                                                            </div>
                                                        </div>
                                                    <?php }?>
                                                <?php $contAnt = $fil2['tipo']; }}?>
                                            </div>
                                            <div class="homButtons">
                                                <a class="hwA" href="editTarea.php?id=<?php echo $fil['id']; ?>"><img src="images/Editar.png" alt="Editar"></a>
                                                <form action="contProyect.php" method="post" onSubmit="return confirm('¿Seguro que desea eliminar la tarea?');">
                                                    <button type="submit" style="cursor:pointer;"class="hwA" name="eliminarTarea" value="<?php echo $fil['id'];?>" ><img src="images/Eliminar.png" alt="Editar"></button>
                                                </form>
                                            </div>
                                        </div>
                                    <?php }?>
                                    <div id="create" class="homework">
                                        <div class="createHom">
                                        <a class="crA" href="crearTarea.php"><img src="images/Crear.png" alt="Crear"></a>
                                        </div>
                                    </div>
                                </div>
                            </section> 
                        </section>
                </section>
            </main>
        </body>
    </section>
</html>