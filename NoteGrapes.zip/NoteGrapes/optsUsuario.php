<!DOCTYPE html>
<?php 
    session_start();
    require_once('phpFunc/conexion.php');
    require_once('phpFunc/camb.php');
    require_once("phpFunc/verif.php");
    require_once("phpFunc/regis.php");
    require_once("phpFunc/mail.php");

// + Configuración de zona horaria
    date_default_timezone_set("America/Mexico_City");
    mysqli_query($conect, "SET time_zone = '" . date('P') . "'");

// + Verificar sesión iniciada  
    if(!isset($_SESSION['username']) || !isset($_SESSION['login'])){
        header('Location: index.html');
        exit();
    }
    $id = $_SESSION['id'];
    $nom = $_SESSION['username'];
    $eml = $_SESSION['email'];
    $fil = "correo";

// + Eliminar sesión temporal (esto para evitar errores al recargar la página)
    if(!isset($_POST['CambDat']) && !isset($_POST['EnviarCod'])){
        unset($_SESSION['temp_newUser']);
        unset($_SESSION['temp_newPs2']);
        //unset($_SESSION['temp_pas']);
    }

    $resTI = eliminarTempTime($conect);
    if(!$resTI){
        echo "<script>alert('Error de carga de pagina, vuelva a intentar');
                window.location.href = 'optsUsuario.php';</script>";
        exit();
    }
//
// ++ Formularios
//
// + Cerrar sesión
    if(isset($_POST['cerCuen'])){

        echo "<script>alert('Nos vemos luego $nom!');</script>";
        unset($_SESSION['username']);
        unset($_SESSION['email']);
        unset($_SESSION['login']);
        unset($_SESSION['id']);
        unset($_SESSION['latestProyect']);
        unset($_SESSION['color']);
        session_destroy();

        echo"<script>window.location.href = 'index.html';</script>";
        exit();
    }

// + Cambiar datos del usuario
    if(isset($_POST['CambDat'])){
        //$resE = true;
        $eml = $_SESSION['email'];

        $nam = $_POST['nom'];
        $ps2 = $_POST['ps2'];
        $pas = $_POST['pas'];

        $_SESSION['temp_newUser'] = '';
        $_SESSION['temp_newPs2']  = '';

    //1- Verificar contrasena de usuario
        $resVC = verificarContrasena($eml, $pas, $conect);

        if($resVC){
            if(empty(trim($ps2)) && empty(trim($nam))){
                echo "<script>alert('Apartados vacios, no se realizaron cambios');</script>";
                exit();
            }else{

    //2.1- Verificar nuevo nombre
                if(!empty(trim($nam))){
                    $col1 = "nombre";
                    $resED = encontrarDatos(trim($nam), $col1, "", $conect);
    
                    if(!$resED){
                        $_SESSION['temp_newUser'] = $nam;
                    }else{       
                        if($nam == $nom && empty($ps2)){
                            echo "<script>alert('Colocó el mismo Nombre, no se realizaron cambios');</script>";
                        }else{
                            echo "<script>alert('Ese nombre ya esta registrado');</script>";
                        }
                        echo "<script>window.location.href = 'optsUsuario.php';</script>";
                        exit();
                    }
                }

    //2.2- Verificar nueva contrasena            
                if(!empty(trim($ps2))){
                    $_SESSION['temp_newPs2'] = $ps2;
                }


    // 3- Crear cuenta temporal
                $nom = $_SESSION['username'];
                $eml = $_SESSION['email'];

                $resUT = registrarUsuarioTemp($eml, $conect);
                if($resUT){

    // 4- Crear mensaje del correo
                    $resCM = crearMensaje(1, $msg);
                    if($resCM != "ERROR"){

    // 5- Enviar el correo
                        $resEC = enviarCorreo($nom, $eml, $resUT, $resCM);
                        if($resEC){
                            echo "<script>alert('Se le envio un codigo de verificación para realizar el cambio. Revise su bendeja de correos.');</script>";
                            echo "<script>
                                window.onload = function() {
                                    document.getElementById('formcodeCU').scrollIntoView({ 
                                        behavior: 'smooth', 
                                        block: 'center' 
                                    });
                                };
                            </script>";
                        }else{
                            echo "<script>alert('No se pudo terminar el cambio');
                            window.location.href = 'optsUsuario.php';</script>";
                            exit();
                        }
                    }else{
                        echo "<script>alert('No se pudo crear el mensaje');
                            window.location.href = 'optsUsuario.php';</script>";
                        exit();
                    }
                }else{
                    echo "<script>alert('ERROR, No se pudo completar la acción, vuelva a intentar');
                        //window.location.href = 'optsUsuario.php';</script>";
                    exit();
                }
            }
        }else{
            echo "<script>alert('Contraseña incorrecta');
                window.location.href = 'optsUsuario.php';</script>";
            exit();
        } 
    }

// + Enviar codigo (Cambiar datos)
    if(isset($_POST['EnviarCod'])){

        $cod = $_POST['code'];        

        $newNam = $_SESSION['temp_newUser'];
        $newPs2 = $_SESSION['temp_newPs2'];
    // 1- Verificar codigo
        $resVO = verificarCodigo($eml, $cod, $conect);
        if($resVO){
    // 2- Enviar cambios
            $resE = actualizarUsuario($id, $newNam, $newPs2, $conect);
            
            if($resE){
                if(!empty($newNam)){
                    $_SESSION['username'] = $newNam;
                }
                echo "<script>alert('Datos actualizados correctamente');</script>";
                
                unset($_SESSION['temp_newUser']);
                unset($_SESSION['temp_newPs2']);

                echo "<script>window.location.href = 'optsUsuario.php';</script>";
                exit();
            }else{
                echo "<script>alert('Error al actualizar datos');
                window.location.href = 'optsUsuario.php';</script>";
                exit();
            }        
        }
    }

// + Eliminar cuenta

    if(isset($_POST['eliCuen'])){

    // 1- Verificar contraseña
        $pass = $_POST['pass'];
        $eml = $_SESSION['email'];

        $resVT = verificarContrasena($eml, $pass, $conect);
        if($resVT){
            $nom = $_SESSION['username'];
                 
    // 2- Crear cuenta temporal
            $resUE = registrarUsuarioTemp($eml, $conect);
            if($resUE){
            
    // 3- Crear mensaje del correo
                $resCN = crearMensaje(2, $msg);
                if($resCN != "ERROR"){

    // 4- Enviar el correo
                    $resEU = enviarCorreo($nom, $eml, $resUE, $resCN);
                    if($resEU){
                        echo "<script> alert('Se le envio un codigo de verificación para realizar la eliminación. Revise su bendeja de correos.');</script>";
                        echo "<script>
                                window.onload = function() {
                                    document.getElementById('formcodeEU').scrollIntoView({ 
                                        behavior: 'smooth', 
                                        block: 'center' 
                                    });
                                };
                            </script>";
                    }else{
                        echo "<script>alert('No se pudo realizar la eliminación');
                        window.location.href = 'optsUsuario.php';</script>";
                        exit();
                        
                    }
                }else{
                    echo "<script>alert('No se pudo crear el mensaje');
                    window.location.href = 'optsUsuario.php';</script>";
                    exit();
                }
            }
        }else{
            echo "<script>alert('Contraseña incorrecta');
                window.location.href = 'optsUsuario.php';</script>";
            exit();
        }     
    }
// + Enviar codigo (Eliminar Usuario)
    if(isset($_POST['EliminarCod'])){

        $cod = $_POST['code'];        

    // 1- Verificar codigo
        $resVO = verificarCodigo($eml, $cod, $conect);
        if($resVO){
    // 2- Eliminar temporal
            $resT = eliminarTemp($fil, $eml, $conect);
            if($resT){
// PROXIMOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
    // 3- Eliminar cuenta
                $resES = eliminarUsuario($id, $conect);

                if($resES){
                    $resCS = crearMensaje(3, $msg);
                    if($resCS){
                        $resEU = enviarCorreo($nom, $eml, "", $resCS);

                        unset($_SESSION['username']);
                        unset($_SESSION['email']);
                        unset($_SESSION['login']);
                        unset($_SESSION['id']);
                        unset($_SESSION['latestProyect']);
                        unset($_SESSION['color']);
                        session_destroy();
                    }

                    
                }else{
                    echo "<script>alert('Error al eliminar cuenta');
                    window.location.href = 'optsUsuario.php';</script>";
                    exit();
                }
                echo "<script>alert('Cuenta eliminada');
                    window.location.href = 'index.html';</script>";
                    exit();
            }                
        } else{
            $resT = eliminarTemp($fil, $eml, $conect);
        }

    }

// + Cambiar colores
    if(!isset($_SESSION['color'])){
        $_SESSION['color'] = "o01";
        $col = $_SESSION['color'];
    }
    if(!isset($col)){
        $col = $_SESSION['color'];
    }

    if(isset($_POST['color'])){
        
        $col  = $_POST['color'];
        $uId  = $_SESSION['id'];
        $resC = actualizarColor($conect, $col, $uId);
        if(!$resC){
            echo "<script>alert('Error al actualizar el color.');
            window.location.href = 'menuPrin.php';</script>";
            exit();
        }
        $_SESSION['color'] = $col;   
        header("Location: optsUsuario.php");
    }

?>

<html lang="es" class="<?php echo $col; ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/colors.css">
        <link rel="stylesheet" href="css/forms.css">
        <link rel="stylesheet" href="css/general.css">
        <link rel="stylesheet" href="css/design.css">
        <script src= "jscript/buttonsAct.js"></script>
        <link rel="icon" type="image/png" sizes="32x32" href="images/icon1.png">
        <title><?php echo $nom; ?></title>
    </head>
    <section class="patUp">
        <script src="jscript/buttonColors.js" defer></script>
        <body class="bodyPrin">
            <main id="mainPrin">
                <section class="mainCont">
                    <aside class="mainAsid">

                        <div id="asidCont">
                            <section class="logoCuen">
                                <a href="menuPrin.php">
                                    <p class="logText">Ir al menu</p>
                                    <img src="images/regresar.png" alt="Cuenta"> 
                                </a>
                            </section>
                            <div class="lin">
                              <hr class="homHr">   
                            </div>
                            <?php if(isset($_SESSION['latestProyect'])){?>
                                <section class="logoCuen">
                                    <a href="contProyect.php?id=<?php echo $_SESSION['latestProyect']; ?>">
                                        <p class="logText">Proyecto reciente</p>
                                        <img src="images/ReciProyecto.png" alt="Cuenta"> 
                                    </a>
                                </section>
                                <div class="lin">
                                    <hr class="homHr">   
                                </div>
                            
                                <section class="logoCuen">
                                    <a href="listProyect.php">
                                        <p class="logText">Mis proyectos</p>
                                        <img src="images/Proyectos.png" alt="Cuenta"> 
                                    </a>
                                </section>
                                <div class="lin">
                                    <hr>   
                                </div>
                            <?php } ?>
                            <section class="logoCuen">
                                <a href="crearProyect.php">
                                    <p class="logText">Crear Proyecto</p>
                                    <img src="images/CrearProyecto.png" alt="Cuenta"> 
                                </a>
                            </section>
                        </div>
                    </aside>
                    <section id="mainHH">
                        <section class="mainHom mainOpts">
                            <section class="contOpts ">

                                <div class="hrLin">
                                    <hr> 
                                </div>

                                <section class="titlOpts">
                                    <h4>Mi Cuenta:</h4>  
                                </section>

                                <div class="hrLin">
                                    <hr> 
                                </div>

                            <!-- ++ INFORMACION DE LA CUENTA-->
                                <section id="logoCount">
                                    <img id="countImg" src="images/Cuenta.png" alt="Color">
                                </section>
                                
                                <section class="contInfo contCount">
                                    <div>
                                        <p style="text-decoration: underline; font-weight: bold; white-space: nowrap">Nombre de Usuario:</p>
                                        <h3 style="text-Overflow:ellipsis; white-space: nowrap"><?php echo htmlspecialchars($nom);?></h3>
                                    </div>
                                    <div>
                                        <p style="text-decoration: underline; font-weight: bold;text-Overflow:ellipsis; ">Correo Electrónico:</p>
                                        <h3 style="text-Overflow:ellipsis; white-space: nowrap; overflow: hidden;"><?php echo $eml;?></h3>
                                    </div>
                                    
                                    
                                </section>
                                

                                <div class="hrLin">
                                    <hr> 
                                </div>
                            <!-- ++ OPCIONES DE LA CUENTA -->

                                <section class="contInfo">
                                <!-- +1 FORMULARIO DE CAMBIAR USUARIO-->
                                    <div class="contChUser">
                                    <!-- TITULO -->
                                        <form action="optsUsuario.php" method="post">                                    
                                            <div class="titleForm">           
                                                <h5 class="textWhite">Cambiar Datos:</h5>
                                                <hr>
                                            </div> 
                                    <!-- DATOS -->
                                            <div class="datForm" id="formDat" style="display: <?php if (!isset($resEC)) {echo 'flex';}else{echo 'none';} ?>;">
                                                
                                                <label for="nombre">Nuevo Nombre de usuario:</label> 
                                                <br>
                                                <input name="nom" class="input" id="nombre" type="text" placeholder="Nombre actual: <?php echo $nom; ?>" maxlength="30">
                                                <br>
                                                <label for="password2">Nueva Contraseña:</label>
                                                <br>
                                                <input name="ps2" class="input" id="password2" type="password" placeholder="Nueva contraseña" minlength="8">
                                                <br>
                                                <label for="password">Contraseña actual:</label>
                                                <br>
                                                <input name="pas" class="input" id="password" type="password" placeholder="Coloque para aplicar cambios" required minlength="8"> 
                                            </div>
                                    <!-- BOTONES -->
                                            <div class="buttonForm" id="formBts" style="display: <?php if (!isset($resEC)) {echo 'flex';}else{echo 'none';} ?>;">
                                                <button class="submit" type="reset">Reestablecer</button>
                                                <button name="CambDat" type="submit" class="submit" >Aplicar Cambios</button>
                                            </div>
                                        </form>
                                    <!---->
                                    <!-- FORMULARIO DE CODIGO (CAMBIAR USUARIO) -->
                                        <form action="optsUsuario.php" method="post" class="form" id="verificacion" onsubmit="return confirm('¿Seguro que desea aplicar los cambios?');">
                                            <div  class="codForm" style="display: <?php if (isset($resEC)) {echo $resEC ? 'block' : 'none';}else{echo 'none';} ?>;">
                                    <!-- DATOS C -->
                                                <div class ="datFormC">
                                                    <label id="formcodeCU" for="code">Código de verificación:</label>
                                                    <input name="code" class="input" id="code" type="password" placeholder="XXXXXX" required>
                                                    <br> 
                                                </div>
                                    <!-- BOTONES C -->
                                                <div class="buttonForm">
                                                    <button type="button" class="submit" onclick="cancelar()">Cancelar</button>         
                                                    <button name="EnviarCod" type="submit" class="submit">Enviar codigo</button>
                                                </div>
                                            </div>
                                        </form> 
                                    </div>
                                <!---->
                                    <div class="hrLin"></div>

                                <!-- +2 FORMULARIO DE BORRAR CUENTA-->
                                    <div class="contChUser">
                                    <!-- TITULO -->
                                        <div class="titleForm">           
                                            <h5 class="textWhite">Eliminar Cuenta:</h5>
                                            <hr>
                                        </div> 
                                    <!-- DATOS -->
                                        <div class="datForm">
                                            <?php if (!isset($resEU)) { ?>
                                                <form action="optsUsuario.php" method="post" onsubmit="return confirm('¿Seguro que desea eliminar su cuenta? Todos sus proyectos y tareas realizadas seran eliminadas tambien.');">
                                                    <div class ="datFormC">
                                                        <label for="password">Contraseña:</label>
                                                        <input name="pass" class="input" id="password" type="password" placeholder="Coloque para eliminar la cuenta" required minlength="8" required>
                                                        <br> 
                                                    </div>
                                    <!-- BOTONES -->
                                                    <div class="buttonForm">
                                                        <button class="aSmall"type="submit" name="eliCuen">Eliminar Cuenta</button>
                                                    </div>
                                                </form>
                                            <?php }?>
                                    <!---->
                                    <!-- FORMULARIO DE CODIGO (BORRAR CUENTA) -->
                                    <!--DATOS C-->
                                            <form action="optsUsuario.php" method="post" class="form">
                                                <div class="codForm" style="display: <?php if (isset($resEU)) {echo $resEU ? 'block' : 'none';}else{echo 'none';} ?>;">
                                                    <div class ="datFormC">
                                                        <label id="formcodeEU" for="code">Código de verificación:</label>
                                                        <input name="code" class="input" id="code" type="password" placeholder="XXXXXX" required>
                                                        <br> 
                                                    </div>
                                    <!--BOTONES C-->
                                                    <div class="buttonForm">
                                                        <button type="button" class="aSmall typeTwo" onclick="cancelar()">Cancelar</button>     
                                                        <pre>        </pre>    
                                                        <button name="EliminarCod" type="submit" class="aSmall">Enviar codigo</button>
                                                    </div>
                                                </div>
                                            </form> 
                                        </div>        
                                    </div>
                                <!---->        
                                <!-- +3 FORMULARIO DE CERRAR SESION-->
                                    <form action="optsUsuario.php" method="post" onsubmit="return confirm('¿Seguro que desea cerrar sesión?');">
                                        <div class="buttonForm">    
                                            <button class="bLarg"type="submit" name="cerCuen" >Cerrar sesión</button>
                                        </div>
                                    </form>
                                <!---->
                                </section>

                                <div class="hrLin">
                                    <hr> 
                                </div>
                            <!---->
                            <!-- ++ OPCIONES DE COLORES DE LA PAGINA -->
                                <form action="optsUsuario.php" method="post">
                                    <section class="titlOpts">
                                        <h4>Paleta de Colores:</h4>  
                                    </section>

                                    <div class="hrLin">
                                        <hr> 
                                    </div>

                                    <section id="logoColor">
                                        <img id="colorImg" src="images/icon1.png" alt="Color"> 
                                        <h2 id="colorText">Texto</h2>             
                                    </section>

                                    <div class="hrLin">
                                        <hr> 
                                    </div>

                                    <section id="contColor">
                                <!-- +3 TIPO DE PALETAS DE COLORES -->  
                                    <!-- TIPOS -->
                                        <div id="divTheme">
                                            <div><h4 style="color:var(--text4);">Oscuro</h4></div>
                                            <div><h4 style="color:var(--text4);">Claro</h4></div>
                                        </div>
                                    <!-- OPCIONES DE COLORES (OSCUROS) -->
                                        <div class="divColors">
                                            
                                            <label class="labelColors">
                                                <input type="radio" name="color" value="o01" onclick="previsualizarColor(this.value)" class="chRadio"><p>Morado</p>
                                            </label>
                                            <label class="labelColors">
                                                <input type="radio" name="color" value="o02" onclick="previsualizarColor(this.value)" class="chRadio"><p>Turquesa</p>
                                            </label>
                                            <label class="labelColors">
                                                <input type="radio" name="color" value="o03" onclick="previsualizarColor(this.value)" class="chRadio"><p>Amarillo</p>
                                            </label>
                                            <label class="labelColors">
                                                <input type="radio" name="color" value="o04" onclick="previsualizarColor(this.value)" class="chRadio"><p>Rojo Tinto</p>
                                            </label>
                                            <label class="labelColors">
                                                <input type="radio" name="color" value="o05" onclick="previsualizarColor(this.value)" class="chRadio"><p>Dorado</p>
                                            </label>
                                            <label class="labelColors">
                                                <input type="radio" name="color" value="o06" onclick="previsualizarColor(this.value)" class="chRadio"><p>Negro</p>
                                            </label>
                                        </div>
                                    <!---->
                                    <!-- OPCIONES DE COLORES (CLAROS) -->
                                        <div class="divColors">
                                            <label class="labelColors">
                                                <input type="radio" name="color" value="c06" onclick="previsualizarColor(this.value)" class="chRadio"><p>Blanco</p>
                                            </label>
                                        </div>
                                        <div class="divBttons">
                                            <button class="bLarg" type="submit">Aplicar</button>          
                                        </div>
                                    <!---->    
                                    </section>

                                    <div class="hrLin">
                                        <hr> 
                                    </div>
                                <!---->
                                </form>
                            <!---->
                            </section>
                        </section> 
                    </section>
                </section>
            </main>
        </body>
    </section>
</html>    