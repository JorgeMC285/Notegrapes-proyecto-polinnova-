<!DOCTYPE html>
<?php
    require_once('phpFunc/conexion.php');
    require_once('phpFunc/verif.php');
    session_start();

// + Verificar sesión iniciada    
    if(!isset($_SESSION['username']) || !isset($_SESSION['login'])){
        header('Location: index.html');
        exit();
    }
    $nom = $_SESSION['username'];

// + Cerrar sesión
    if(isset($_POST['cerCuen'])){
        
        echo "<script>alert('Nos vemos luego $nom!');</script>";
        unset($_SESSION['username']);
        unset($_SESSION['email']);
        unset($_SESSION['login']);
        unset($_SESSION['id']);
        unset($_SESSION['latestProyect']);
        unset($_SESSION['color']);
        session_destroy();

        echo"<script>window.location.href = 'index.html';</script>";
        exit();
    }

// + 1- Encontrar proyecto reciente del usuario
    $lpId = null;

    $uId = obtenerValoresdelUsuario($conect, $nom, "id");
    
    if(!$uId){
        echo "<script>alert('Error al cargar datos del usuario.');
        window.location.href = 'index.html';</script>";
        exit();
    }
    $_SESSION['id'] = $uId;
    
    $resE = encontrarProyectoReciente($conect, $uId, "MAX(id)");
    if($resE){
        $_SESSION['latestProyect'] = $resE;
        $lpId = $_SESSION['latestProyect'];
    }else{
        //echo "<script>alert('No tienes proyectos creados.');</script>";
        $lpId = null;
        $_SESSION['latestProyect'] = $lpId;
    }


// + 2- Encontrar colores del usuario
    if(!isset($_SESSION['color'])){
        $uId = $_SESSION['id'];
        $resC = obtenerColor($conect, $uId);
        if($resC){
            $_SESSION['color'] = $resC;
            $col = $_SESSION['color'];
        }
    }
    $col = $_SESSION['color'];
    
?>

<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo "Menu principal de " . $nom; ?></title>

        <link rel="stylesheet" href="css/colors.css">
        <link rel="stylesheet" href="css/forms.css">
        <link rel="stylesheet" href="css/menus.css">
        <script src="jscript/buttonColors.js"></script>
        <link rel="icon" type="image/png" sizes="32x32" href="images/icon1.png">
        <script>
        // Ejecución inmediata con el color de este usuario
            const colorUsuario = '<?php echo $col; ?>';
            cambiarColores(colorUsuario);
        </script>
    </head>
    <body class="bodyPrin">

        <section class="patUp">
            <main class="mainMenu">
                
                <section id="upMain">
                    <h1>¡Bienvenido!</h1>
                    <h2>¿Qué quieres hacer?</h2>
                </section>
                <section id="downMain">
                   <div class="divDown">
                        <div class="divCont">
                            <a href="crearProyect.php" class="aLarg">Crear Proyecto</a>
                            <?php if($lpId != null){ ?>
                                    <a href="contProyect.php?id=<?php echo $lpId; ?>" class="aMediu">Proyecto Reciente</a>
                                    <a href="listProyect.php" class="aMediu">Mis Proyectos</a>
                                <?php }else{ echo "<button disabled class='bMediu'>Proyecto Reciente</button>
                                                <button disabled class='bMediu'>Mis Proyectos</button>"; 
                                } ?>    
                        </div>
                        <div class="linMenu">
                            <hr>
                        </div>
                        <div class="divCont">
                            <a href="optsUsuario.php" class="aLarg">Mi Cuenta</a>
                            <form action="menuPrin.php" method="post" onsubmit="return confirm('¿Seguro que desea cerrar sesión?');"><button type="submit" name="cerCuen" class='bMediu'>Cerrar sesión</button></form>
                        </div>    
                   </div>
                </section>
            </main>
        </section>
        <footer class="footForms">
            <p>© 2024 TurboZone. Todos los derechos reservados.</p>
        </footer>
    </body>
</html>