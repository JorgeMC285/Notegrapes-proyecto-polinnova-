<?php 
// + actualizarProyecto
    function actualizarProyecto($conect, $tit, $des, $pro){
        if(empty(trim($pro)) || !is_numeric($pro)){
            echo "<script>alert('ERROR actualizarProyecto()');</script>";
            return false;
        }
        if (empty(trim($tit))){
            echo "<script>alert('Complete el campo de título para aplicar los cambios.');</script>";
            return false;
        }
        $sen = "UPDATE proyects SET titulo = '$tit', descripcion = '$des' WHERE id = $pro";
        $res = mysqli_query($conect, $sen);

        if (!$res) {
            echo "<script>alert('Error al guardar los cambios.');</script>";
            return false;
        }

        return true;
    }

// + actualizarColor
    function actualizarColor($conect, $col, $uId){
        $ver = "UPDATE users SET color = '$col' WHERE id = $uId";
        $resul = mysqli_query($conect, $ver);

        if ($resul) {
            return true;
        }else{
            return false;
        }
    }
    function actualizarUsuario($uId, $newNam, $newPs2, $conect){
        if(empty($uId)){
            echo "<script>alert('ERROR actualizarUsuario()');</script>";
            return false;
        }
        if(empty(trim($newNam)) && empty(trim($newPs2))){
            return false;
        }

        if(!empty(trim($newNam))){
            $ver = "UPDATE users SET nombre = '$newNam' WHERE id = $uId";
            $resul = mysqli_query($conect, $ver);
            if(!$resul){
                return false;
            }
        }
        if(!empty(trim($newPs2))){
            $hashPas = password_hash($newPs2, PASSWORD_DEFAULT);
            $ver2 = "UPDATE users SET contrasena = '$hashPas' WHERE id = $uId";
            $resul2 = mysqli_query($conect, $ver2);
            if(!$resul2){
                return false;
            }
        }
        return true;
    }
// + ActualizarCheck
    function actualizarCheck($conect, $chId, $hkId, $val){
        if(empty($chId) || empty($hkId) || empty($conect)){
            echo "<script>alert('ERROR actualizarCheck()');</script>";
            return false;
        }

        $ver = "UPDATE task_content SET estado = $val WHERE id = $chId AND id_task = $hkId";
        $resul = mysqli_query($conect, $ver);

        if ($resul) {
            return true;
        }else{
            return false;
        }
    }
// + ActualizarTarea
    function actualizarTarea($conect, $tkId, $tit, $des, $fch){
        if(empty($tit)){
            echo "<script>alert('El titulo es necesario, coloque uno a su tarea.');</script>";
            return false;
        }

        $sen = "UPDATE tasks SET titulo = '$tit', descripcion = '$des', fecha = '$fch' WHERE id = $tkId";
        $result = mysqli_query($conect, $sen);
        if(!$result){
            echo "<script>alert('Error al crear la tarea');</script>";
            return false;
        }
        return true;
    }
?>