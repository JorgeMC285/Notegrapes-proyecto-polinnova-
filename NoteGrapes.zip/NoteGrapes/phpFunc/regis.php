<?php 
// + registrarUsuario

    function registrarUsuario($nom, $eml, $pas, $conect){

    //Encriptar contraseña    
        $hashPas = password_hash($pas, PASSWORD_DEFAULT);
    //Sentencia que se envia a la base de datos
        $sentencia = "INSERT INTO users(nombre, email, contrasena) VALUES('$nom','$eml', '$hashPas')";
        $funciono  = mysqli_query($conect, $sentencia);

        $_SESSION['username'] = $nom;

        echo "<script>alert('¡Se guardaron los datos correctamente!');</script>";
        return true;
    }
// + EliminarUsuario
    function eliminarUsuario($id, $conect){
        $comand = "DELETE FROM users WHERE id = $id";
        $resul  = mysqli_query($conect, $comand);
        
        if(!$resul){
            return false;  
        }
        return true;

    }
// + RegistrarUsuarioTemporal

    function registrarUsuarioTemp($eml, $conect){
    //codigo de verificacion (6 digitos)
        $code = random_int(100000, 999999);                 
        $hashCode = password_hash($code, PASSWORD_DEFAULT); //encriptar codigo de verificacion
    
    //fecha de expiracion (5min)
        $exp = date("Y-m-d H:i:s", time() + 300);          
    
    //Sentencia de registro
        $comand = "INSERT INTO tempusers (correo, codigo, vencimiento) VALUES ('$eml', '$hashCode', '$exp');";
        $resul  = mysqli_query($conect, $comand);
        
        if($resul){
            return $code;  
        }
        return false;
    }
// + EliminarUsuarioTemporal

    function eliminarTemp($nam, $Eval, $conect){
        $comand = "DELETE FROM tempusers WHERE ".$nam." = '$Eval'";
        $resul  = mysqli_query($conect, $comand);
        if(!$resul){
            echo "<script>alert('Error al eliminar usuario temporal');</script>";
            return false;
        }else{
            return true;

        }
    }

// + EliminarUsuarioTemporal(tiempo)
    function eliminarTempTime($conect){
        $limTemp = "DELETE FROM tempusers WHERE vencimiento < NOW()";
        $resul = mysqli_query($conect, $limTemp);
        if($resul){
            return true;
        }else{
            return false;
        }
    }

// + RegistrarProyecto
    function registrarProyecto($conect, $tit, $des, $uId){
        if(empty($uId) || empty($tit)){
            echo "<script>alert('No hay usuario o título de proyecto');</script>";
            return false;
        }

        $sen = "INSERT INTO proyects (id_admin, titulo, descripcion) VALUES ($uId, '$tit', '$des')";
        $result = mysqli_query($conect, $sen);
        if(!$result){
            echo "<script>alert('Error al crear el proyecto');</script>";
            return false;
        }
        return true;
    }

// + EliminarProyecto
    function eliminarProyecto($conect, $idP, $uId){
        if(empty($idP) || empty($uId)){
            echo "<script>alert('Error al cargar los datos del usuario');</script>";
            return false;
        }
        $sen = "DELETE FROM proyects WHERE id = $idP AND id_admin = $uId";
        $result = mysqli_query($conect, $sen);
        if(!$result){
            echo "<script>alert('Error al eliminar el proyecto');</script>";
            return false;
        }
        return true;

    }
// + RegistrarTarea
    function registrarTarea($lpId, $uId, $tit, $des, $fch, $conect){
        if(empty($lpId) || empty($uId)){
            echo "<script>alert('Error al cargar los datos del usuario');</script>";
            return false;
        }
        if(empty(trim($tit))){
            echo "<script>alert('El titulo es necesario, coloque uno a su tarea.');</script>";
            return false;
        }

        $sen = "INSERT INTO tasks (id_proyect, id_user, titulo, descripcion, fecha) VALUES ($lpId, $uId, '$tit', '$des', '$fch')";
        $result = mysqli_query($conect, $sen);
        $tkId = mysqli_insert_id($conect);
        if(!$result){
            echo "<script>alert('Error al crear la tarea');</script>";
            return false;
        }
        return $tkId;
    }
// + EliminarTarea
    function elimTarea($conect, $id, $uId){
        if(empty($id)){
            return false;
        }
        $sen = "DELETE FROM tasks WHERE id = $id AND id_user = $uId";
        $result = mysqli_query($conect, $sen);
        if(!$result){
            echo "<script>alert('Error al eliminar el proyecto');</script>";
            return false;
        }
        return true;
    }
// + crearContenidoTarea
    function crearContenidoTarea($conect, $resRT, $uId, $tipo, $orden, $contenido){
        $sen = "INSERT INTO task_content (id_task, id_user, tipo, orden, contenido) VALUES ($resRT, $uId, '$tipo', '$orden', '$contenido')";
        $res = mysqli_query($conect, $sen);
        
        return true;
    }
?>