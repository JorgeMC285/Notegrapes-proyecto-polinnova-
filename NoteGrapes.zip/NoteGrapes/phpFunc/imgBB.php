<?php
// CREA LA URL DE LA IMAGEN SUBIDA A IMGBB Y LA DEVUELVE PARA GUARDARLA EN LA BASE DE DATOS 0e0f2f4f43896280b4435cba5fa69f0c

function subirImagen($imagenTmp){

    $apiKey = "0e0f2f4f43896280b4435cba5fa69f0c";

    $imageData = base64_encode(
        file_get_contents($imagenTmp)
    );

    $url = "https://api.imgbb.com/1/upload?key=".$apiKey;

    $data = [
        'image' => $imageData
    ];

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);

    curl_setopt($ch, CURLOPT_POST, true);

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

    $response = curl_exec($ch);

    if(curl_errno($ch)){

        curl_close($ch);

        return false;
    }

    curl_close($ch);

    $resultado = json_decode($response, true);

    if(isset($resultado['data']['url'])){
        
        return $resultado['data']['url'];
    }else{
        
        return false;
    }
}
?>