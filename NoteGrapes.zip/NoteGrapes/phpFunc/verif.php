<?php 

// + verificarDatos

    function verificarDatos($nom, $eml, $pas, $ps2, $conect){
    // Campos vacíos
        if(empty(trim($nom)) || empty(trim($pas)) || empty(trim($eml)) || empty(trim($ps2))){
            echo "<script>alert('Los apartados estan vacios, porfavor de llenar el formulario');</script>";
            return false;
        }
    // Contraseñas no coinciden
        if($pas != $ps2){
            echo "<script>alert('Las contraseñas no coinciden');</script>";
            return false;
        }
    // Evitar usuarios duplicados
        $ver = "SELECT * FROM users WHERE nombre = '$nom' OR email = '$eml'";
        $resul = mysqli_query($conect, $ver);

        if (mysqli_num_rows($resul) > 0) {
            echo "<script>alert('Datos de su formulario ya son usados, favor de cambiar el nombre y/o correo colocados');</script>";
            return false;
        }
        //echo "2- esto se hizo en verif.php <br>";
        return true;
    }
    
// + verificarCodigo

    function verificarCodigo($eml, $cod, $conect){
        // 1. Limpiamos cualquier código viejo antes de buscar (Mantenimiento automático)
        mysqli_query($conect, "DELETE FROM tempusers WHERE vencimiento < NOW()");

        // 2. Buscamos el código más reciente que NO haya vencido
        // Usamos NOW() directamente en SQL para que la comparación sea exacta
        $ver = "SELECT * FROM tempusers 
                WHERE correo = '$eml' 
                AND vencimiento > NOW() 
                ORDER BY tiempo_creado DESC LIMIT 1";
                
        $resul = mysqli_query($conect, $ver);

        if (mysqli_num_rows($resul) > 0) {
            $filas = mysqli_fetch_assoc($resul);
            
            // 3. Verificar si el hash del código coincide
            if(!password_verify($cod, $filas['codigo'])){
                echo "<script>alert('El código de verificación es incorrecto.');</script>";
                return false;
            } else {
                // ¡Éxito!
                return true;
            }
        } else {
            // Si no hay resultados, es porque el correo no existe o el código YA VENCIÓ
            // y fue ignorado por el "AND vencimiento > NOW()" o borrado por el DELETE inicial
            echo "<script>alert('El código ha expirado o es inválido. Intente de nuevo.');</script>";
            return false;
        }
    }

// + encontrarDatos

    function encontrarDatos($nom, $col1, $col2, $conect){
    //Error del llamado a la funcion
        if(empty(trim($nom))){
            echo '<script>alert("verif.php linea 67 ERROR:El campo de valor a buscar está vacío (nom), por favor ingrese un valor");</script>';
            return false;
        }
        if(empty(trim($col1))){
            echo '<script>alert("verif.php linea 71 ERROR:El campo de columna a buscar está vacío (col1), por favor ingrese un valor");</script>';
            return false;
        }
    //Busqueda de datos (un solo campo)
        if(empty(trim($col2))){
            $ver   = "SELECT * FROM users WHERE $col1 = '$nom'";
            $resul = mysqli_query($conect, $ver);
    
    //Busqueda de datos (dos campos)        
        }else{
            $ver   = "SELECT * FROM users WHERE $col1 = '$nom' OR $col2 = '$nom'";
            $resul = mysqli_query($conect, $ver);
            
        }
        $fila = mysqli_fetch_assoc($resul);

        if ($fila) {
            if($fila[$col1] == $nom){
                return $fila[$col1];
            }else{
                return $fila[$col1];
            }
        } else {
            return false;
        }  
    }
    function verificarContrasena($nom, $pas, $conect){
    //Error del llamado a la funcion
        if(empty(trim($nom))){
            echo '<script>alert("verif.php linea 94 ERROR:El campo de valor a buscar está vacío (nom), por favor ingrese un valor");</script>';
            return false;
        }
        if(empty(trim($pas))){
            echo '<script>alert("verif.php linea 98 ERROR:El campo de valor a buscar está vacío (pas), por favor ingrese un valor");</script>';
            return false;
        }
        if (str_contains($nom, '@')) {
            $ver = "SELECT * FROM users WHERE email = '$nom'";
        }else{
            $ver = "SELECT * FROM users WHERE nombre = '$nom'";
        }
    //Busqueda del usuario
        
        $resul = mysqli_query($conect, $ver);
        $fila = mysqli_fetch_assoc($resul);

        if ($fila) {
            if(password_verify($pas, $fila['contrasena'])){
                return true;
            }else{
                return false;
            }
        } else {
            return false;
        }  
    }

// + encontrarProyecto
    function encontrarProyecto($idB, $id, $conect){
        $ver    = "SELECT * FROM proyects WHERE $idB = $id";
        $result = mysqli_query($conect, $ver);
        $fila    = mysqli_fetch_assoc($result);
        if ($fila) {
            return $fila;
        } else {
            return false;
        }
    }
// + EncontrarProyectoReciente
    function encontrarProyectoReciente($conect, $uId, $sel){
        //EDITAR AL CREAR LOS PERMISOSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS
        $ver = "SELECT $sel FROM proyects WHERE id_admin = $uId";
        $resul = mysqli_query($conect, $ver);
        $fila = mysqli_fetch_assoc($resul);
        if ($fila) {
            return $fila[$sel];
        } else {
            return false;
        }
    }
// + VerificarProyecto
    function verificarProyecto($uId, $tit , $conect){
        if(empty($uId) || empty(trim($tit)) || empty($conect)){
            return false;
        }
        $ver = "SELECT titulo FROM proyects WHERE id_admin = $uId AND titulo = '$tit';";
        $resul = mysqli_query($conect, $ver);
        $fila = mysqli_fetch_assoc($resul);

        if($fila > 0){
            return false;
        }
        return true;

    }
// + VerificarAdminProyecto
    function verificarAdminProyecto($conect, $uId, $pId){
        $ver = "SELECT id FROM proyects WHERE id = $pId AND id_admin = $uId";
        $resul = mysqli_query($conect, $ver);
        $fila = mysqli_fetch_assoc($resul);
        if ($fila) {
            return true;
        } else {
            return false;
        }
    }
// + obtenerValoresdelUsuario   
    function obtenerValoresdelUsuario($conect, $nom, $var){

        if (str_contains($nom, '@')) {
            $ver    = "SELECT $var FROM users WHERE email = '$nom'";
        } else{
            $ver    = "SELECT $var FROM users WHERE nombre = '$nom'";
        }
        
        $result = mysqli_query($conect, $ver);
        $fila    = mysqli_fetch_assoc($result);
        if ($fila) {
            return $fila[$var];
        } else {
            return false;
        }
    }

// + obtenerColor
    function obtenerColor($conect, $uId){
        $ver    = "SELECT color FROM users WHERE id = $uId";
        $result = mysqli_query($conect, $ver);
        $fila    = mysqli_fetch_assoc($result);
        if ($fila) {
            return $fila['color'];
        } else {
            return false;
        }
    }

// + obtenerProyectosUsuario
    function obtenerProyectosUsuario($conect, $uId, $col, $ord){
        if(empty($uId) || empty($col) || empty($ord)){
            return false;
        }
    
        $ver    = "SELECT * FROM proyects WHERE id_admin = $uId ORDER BY $col $ord";
        $result = mysqli_query($conect, $ver);
        
        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                return $result;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
// + obtenerTareasProyecto
    function obtenerTareasProyecto($conect, $pId, $col, $ord){
        if(empty($pId) || empty($col) || empty($ord)){
            return false;
        }
    
        $ver    = "SELECT * FROM tasks WHERE id_proyect = $pId ORDER BY $col $ord";
        $result = mysqli_query($conect, $ver);
        
        if ($result) {
            return $result;
        } else {
            return false;
        }
    }
// + obtenerTarea
    function obtenerTarea($conect, $hkId){
        if (empty($hkId)){
            return false;
        }
        $ver = "SELECT * FROM tasks WHERE id = $hkId";
        $result = mysqli_query($conect, $ver);

        if(!$result){
            die(mysqli_error($conect));
        }
        $cont = mysqli_fetch_assoc($result);
        return $cont;

    }
// + obtenerContenidoTarea
    function obtenerContenidoTarea($conect, $tkId){
        $ver = "SELECT * FROM task_content WHERE id_task = $tkId ORDER BY orden ASC";
        $result = mysqli_query($conect, $ver);

        if(!$result){
            die(mysqli_error($conect));
        }
        return $result;
    }
?>