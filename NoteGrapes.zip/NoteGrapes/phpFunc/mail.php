<?php 
//LIBRERIA USADA: "PHPMailer"

// + Importar las clases de PHPMailer en los 'namespace' globales
    //Deben de colocarse encima del script
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

// + Mensajes para cada correo (llamar con indice desde 0)
    $msg = [
        'Parece que intentas iniciar sesión en Notegrapes!🌟 <br> A continuación, te dejamos tu codigo de confirmación para que puedas iniciar sesion: <br><br>',
        'Parece que quieres cambiar datos de tu cuenta de usuario. <br> A continuación, te dejamos tu codigo de confirmación para que puedas realizar el cambio 😉. <br><br>',
        'Parece que quieres eliminar tu cuenta. <br> A continuación, te dejamos tu codigo de confirmación para que puedas realizarlo. <br><br>',
        'Esperamos que hayas disfrutado utilizar nuestra pagina. <br> Ojala volvernos a encontrar.👋'
    ];

//
// ++ FUNCIONES
//
// + CrearMensaje
    function crearMensaje($num, $ary){
        return $ary[$num] ?? "ERROR";
    }

// + EnviarCorreo
    function enviarCorreo($nom, $eml, $code, $men){
      
    // 1- Verificacion de datos
        if(empty(trim($nom)) || empty(trim($eml)) || empty(trim($men))){
            echo "<script>alert('No se pudo enviar el correo, faltan datos');</script>";
            return false;
        }
        //Clases
        require 'mailer\Exception.php';
        require 'mailer\PHPMailer.php';
        require 'mailer\SMTP.php';
        
        //Zona horaria
        date_default_timezone_set("America/Mexico_City");  

        $mail = new PHPMailer(true);
        try{
    // 2- Configuracion del servidor SMTP
            $mail->CharSet = 'UTF-8';
            $mail->SMTPDebug = 0;                                       //Enable verbose debug output, 2 o 0
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                       //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'notegrapes@gmail.com';                 //SMTP username
            $mail->Password   = 'amyt xpqz fnww vbzv';                  //SMTP password
            $mail->SMTPSecure = "tls";                                  //Enable implicit TLS encryption
            $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
        
    // 3- Datos del usuario
            $to     = $eml; //correo del usuario registrado
            $toName = $nom; //nombre del usuario registrado
        
    // 4- Recipiente
            $mail->setFrom('notegrapes@gmail.com', 'Notegrapes');
            $mail->addAddress($to, $toName);     //Agregar recipiente
    
    // 5- Contenido del correo
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = '🍇 Hola '.$toName;
            
            if(!empty($code)){
                $mail->Body    = $men.'<b>'.$code.'</b>';
            }else{
                $mail->Body    = $men;
            }
            
            $mail->send();
            return true;

        }catch(Exception $e){
            echo "ERROR DE PHPMailer: {$mail->ErrorInfo}";
            return false;
        }
    }
?>