<?php
        $ser  = 'localhost';
        $usr  = 'admin'; //El usuario 'root' no sera el que se usara, se realizara otro -J
        $pas  = '4dm1nNG';
        $bds  ='notegrapes2'; 
    
        $conect = mysqli_connect($ser, $usr, $pas, $bds);
/*
    if ($conect) {
        echo "Si";
    }else{
        echo "no";
    }*/ 
    
?>