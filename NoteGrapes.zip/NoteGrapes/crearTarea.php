<!DOCTYPE html>
<?php
    session_start();
    require_once('phpFunc/conexion.php');
    require_once('phpFunc/regis.php');
    require_once('phpFunc/verif.php');
    require_once('phpFunc/imgBB.php');
    
//Zona horaria
    date_default_timezone_set("America/Mexico_City");  

// + Verificar sesión iniciada    
    if(!isset($_SESSION['username']) || !isset($_SESSION['login'])){
        header('Location: index.html');
        exit();
    }
    $uId = $_SESSION['id'];
    $nom = $_SESSION['username'];

// + Verificar el id del proyecto
    if(!isset($_SESSION['latestProyect'])){
        header('Location: menuPrin.php');
        exit();
    }
    $lpId = $_SESSION['latestProyect'];

// + Encontrar Proyecto
    $resP = encontrarProyecto("id", $lpId, $conect);
    if(!$resP){
        echo "<script>alert('No se encontró el proyecto.');
                 window.location.href = 'menuPrin.php';</script>";
    }
    $proTit = $resP['titulo'];
    $proDes = $resP['descripcion'];
// FUNCIONES
// + Crear Tarea
    if(isset($_POST['crearTarea'])){
        // 1- Verificar titulo
        $tit = $_POST['tit'];
        $des = $_POST['des'];
        $fch = $_POST['fch'];

        $resRT = registrarTarea($lpId, $uId, $tit, $des, $fch, $conect);
        if($resRT){
            echo "<script>alert('Tarea creada.');</script>";

            if(isset($_POST['elementos'])) {
                foreach($_POST['elementos'] as $elemento) {

                    $tipo = $elemento['tipo'];
                    $orden = $elemento['orden'];
                    if($tipo === 'img'){
                        $tmp = $_FILES['imagenes']['tmp_name'][$orden];
                        if(!isset($_FILES['imagenes']['tmp_name'][$orden]) || empty($_FILES['imagenes']['tmp_name'][$orden])){
                            echo "<script>alert('Error al crear la tarea con imagen.');
                                window.location.href = 'crearTarea.php';</script>";
                            
                            exit();
                        }
                        $contenido = subirImagen($tmp);
                    }else{
                        $contenido = $elemento['contenido'];
                    }
                    $resCC = crearContenidoTarea($conect, $resRT, $uId, $tipo, $orden, $contenido);
                    if(!$resCC){
                        echo "<script>alert('Error al crear la tarea.');
                            window.location.href = 'crearTarea.php';</script>";
                        exit();
                    }
                }
            }
            echo "<script>window.location.href = 'contProyect.php?id=" . $lpId . "';</script>";
            exit();
        }else{

            echo "<script>window.location.href = 'crearTarea.php';</script>";
            exit();
        }
    }

// + Cargar colores del proyecto
    $col = $_SESSION['color'];
?>

<html lang="es" class="<?php echo $col; ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/colors.css">
        <link rel="stylesheet" href="css/general.css">
        <link rel="stylesheet" href="css/forms.css">
        <link rel="stylesheet" href="css/design.css">
        <link rel="icon" type="image/png" sizes="32x32" href="images/icon1.png">
        <title><?php echo htmlspecialchars($proTit, ENT_QUOTES, 'UTF-8'); ?></title>
    </head>
    <section class="patUp">
        <script src="jscript/buttonColors.js" defer></script>
        <body class="bodyPrin">
            <main id="mainPrin">
                <section class="mainCont">
                    <aside class="mainAsid">

                        <div id="asidCont">
                            <section class="logoCuen">
                                <a href="menuPrin.php">
                                    <p class="logText">Ir al menu</p>
                                    <img src="images/regresar.png" alt="Cuenta"> 
                                </a>
                            </section>
                            <div class="lin">
                              <hr>   
                            </div>
                            <section class="logoCuen">
                                <a href="optsUsuario.php">
                                    <p class="logText"><?php echo $nom; ?></p>
                                    <img src="images/Cuenta.png" alt="Cuenta">
                                </a>     
                            </section>

                            <div class="lin">
                                <hr class="homHr">   
                            </div>


                            <section class="logoCuen">
                                <a href="contProyect.php?id=<?php echo $_SESSION['latestProyect']; ?>">
                                    <p class="logText">Proyecto reciente</p>
                                    <img src="images/ReciProyecto.png" alt="Cuenta"> 
                                </a>
                            </section>

                            <div class="lin">
                              <hr>   
                            </div>
                            <section class="logoCuen">
                                <a href="listProyect.php">
                                    <p class="logText">Mis proyectos</p>
                                    <img src="images/Proyectos.png" alt="Cuenta"> 
                                </a>
                            </section>
                            <div class="lin">
                              <hr>   
                            </div>
                            <section class="logoCuen">
                                <a href="crearProyect.php">
                                    <p class="logText">Crear Proyecto</p>
                                    <img src="images/CrearProyecto.png" alt="Cuenta"> 
                                </a>
                            </section>
                            
                        </div>


                    </aside>
                    <section id="mainHH">
                        <header id="mainHead">
                            <div id="headTitl">
                                <h4><?php echo htmlspecialchars($proTit, ENT_QUOTES, 'UTF-8'); ?></h4>
                            </div>
                            <div id="headDesc">
                                <textarea disabled name="" id="desc"><?php echo htmlspecialchars($proDes, ENT_QUOTES, 'UTF-8'); ?></textarea>
                            </div>
                        </header>
                        <section class="mainHom">
                            <div class="cont contHome">
                                <form action="crearTarea.php" method="POST" enctype="multipart/form-data">

                                    <div class="homework homOptions">
                                        <div class="homCont homInputs">

                                            <div class="homInfo">
                                                <br>
                                                <label for="titulo"><h5>*Titulo de la tarea:</h5></label>
                                                <input class="inputHom" type="text" id="titulo" name="tit" maxlength="100" placeholder="Ingrese el título de la tarea" required>
                                                <br>
                                            </div>
                                            
                                            <div class="homInfo">
                                                <br>
                                                <label for="descripcion"><h5>Descripción (tarea):</h5>(opcional)</label>
                                                <br>
                                                <textarea class="inputHom textarea" id="descripcion" name="des" maxlength="255" placeholder="Ingrese la descripción de la tarea (Opcional)"></textarea>
                                            </div>
                                            <div class="homLines">
                                                <hr>
                                            </div>

                                            <div class="homInfo">
                                                <label for="fecha"><h5>Fecha de entrega:</h5>(opcional)</label> 
                                                    <input class="inputHom" type="date" id="fecha" name="fch" min="<?php echo date('Y-m-d'); ?>">
                                                <br>
                                            </div>

                                            <div class="homLines">
                                                <hr>
                                            </div>

                                            <div class="homInfo">
                                                <h5>Contenido:</h5>
                                            </div>

                                            <div class="homCreate">
                                                <select name="addCon" id="agregar">
                                                    <option value="" disabled selected>Agregar...</option>
                                                    <option value="check">Casilla de verificación</option>
                                                    <option value="description">Descripción</option>
                                                    <option value="img">Imagen</option>
                                                </select>
                                                <br>
                                                <button class="submit bMediu" type="button" id="addC" >Agregar:</button>
                                            </div>

                                            <div class="homLines">
                                                <hr>
                                            </div>
                                            <input id="ordenCont"type="hidden" value = "0";>

                                            <div id="contCreated" class="homInfo">
                                                
                                                <!--
                                                elementos[id][contenido]    (URLS, texto)
                                                elementos[id][tipo]         (check, description, img)
                                                elementos[id][orden]        (0, 1, 2, ..)

                                                elementos[id][id]

                                                imagenes[id]
                                                    $_FILES['imagenes']['tmp_name'][id]
                                                -->
                                            </div>     
                                        </div>
                                        <div class="homButtons homButtons2">
                                            <button name="crearTarea" type="submit" class="submit bMediu">Guardar +</button>
                                            <button class="submit bMediu" onclick="location.href='contProyect.php?id=<?php echo $_SESSION['latestProyect']; ?>'">Cancelar</button>
                                            
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </section>
                    </section>
                </section>
            </main>
            <script src= "jscript/createCont.js"></script>
        </body>
    </section>
</html>