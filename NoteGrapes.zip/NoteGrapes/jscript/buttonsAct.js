function cancelar(){
    let element = document.querySelectorAll(".codForm");
    let form1 = document.getElementById("formDat");
    let formB = document.getElementById("formBts"); 
    //alert('Hola');
    if (form1) form1.style.display = "flex";
    if (formB) formB.style.display = "flex";

    element.forEach(function(el){
        el.style.display = "none";
    });
}