const temas = { 'o01':{fil:'brightness(0) saturate(100%) invert(19%) sepia(59%) saturate(2157%) hue-rotate(285deg) brightness(100%) contrast(92%)',col:'#b192bd',bac:'#232323'},
                'o02':{fil:'brightness(0) saturate(100%) invert(65%) sepia(32%) saturate(609%) hue-rotate(89deg) brightness(95%) contrast(97%)',col:'#99F6E4', bac:'#1e2e3b'},
                'o03':{fil:'brightness(0) saturate(100%) invert(73%) sepia(12%) saturate(2402%) hue-rotate(358deg) brightness(89%) contrast(82%)',col:'#d38a45', bac:'#2b1c14'},
                'o04':{fil:'brightness(0) saturate(100%) invert(13%) sepia(85%) saturate(3500%) hue-rotate(350deg) brightness(90%) contrast(100%)',col:'#bd9292', bac:'#231f1f'},
                'o05':{fil:'brightness(0) saturate(100%) invert(80%) sepia(13%) saturate(1408%) hue-rotate(358deg) brightness(85%) contrast(82%)',col:'#BFAF88', bac:'#141414'},
                'o06':{fil:'brightness(0) saturate(100%) invert(82%) sepia(0%)saturate(4496%) hue-rotate(180deg) brightness(109%) contrast(101%)',col:'#aaaaaa', bac:'#030303'},
                'c06':{fil:'brightness(0) saturate(100%) invert(18%) sepia(0%) saturate(4496%) hue-rotate(180deg) brightness(91%) contrast(99%)',col:'#555555', bac:'#fcfcfc'}
            };
const root = document.documentElement;

function cambiarColores(col) {
    if (!col) return;
    
    root.classList.remove(...Object.keys(temas));
    root.classList.add(col);
    localStorage.setItem("tema", col);
}
function previsualizarColor(color){
    
    const img = document.getElementById('colorImg');
    const text = document.getElementById('colorText');
    const back = document.getElementById('logoColor');

    img.style.filter = temas[color].fil;
    text.style.color = temas[color].col;
    back.style.backgroundColor = temas[color].bac;

}
