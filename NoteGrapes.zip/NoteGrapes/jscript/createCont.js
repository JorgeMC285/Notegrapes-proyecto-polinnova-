document.getElementById("addC").addEventListener('click', () => {
    const bloques = document.querySelectorAll('.bloque');
    let order = bloques.length;

    const div = document.createElement('div');
    div.classList.add('bloque');

    let type = document.getElementById("agregar").value;
    let content = "";

    // `` <- Blacticks, son para realizar saltos de linea y escribir el codigo de forma mas limpia
    if(type === "check"){
        content = `
            <input type='text'
            class='inputHom'
            name='elementos[${order}][contenido]'
            placeholder='✓ Nuevo check'>
        `;
    }else if(type === "description"){
        content = `
            <textarea
            class='inputHom textarea'
            style='height:50px;'
            name='elementos[${order}][contenido]'
            placeholder='✎ Nueva descripción'></textarea>
        `;
    }else if(type === "img"){
        content = `
            <input type='file'
            class='imageInputHom'
            name='imagenes[${order}]'
            accept='image/*'>
        `;
    }else{
        alert("Selecciona un tipo.");
        return;
    }
    content += `
        <input type='hidden' 
        
        value='${type}'
        name='elementos[${order}][tipo]'>

        <input type='hidden'
        class='ordenInput'
        value='${order}'
        name='elementos[${order}][orden]'>
    `;
    div.dataset.type = type;
    div.innerHTML = content + `<br> <br> 
                    <button type="button" class="sbButton" onclick="subirElemento(this)">
                        ↑
                    </button>

                    <button type="button" class="sbButton" onclick="bajarElemento(this)">
                        ↓
                    </button>

                    <button class="bMediu" 
                    type='button' class='deleteBtn' 
                    onclick='eliminarElemento(this)'>Eliminar</button> 

                    <div class="homLines">
                       <hr>
                    </div>`;

    document.getElementById('contCreated').appendChild(div);

    document.getElementById("agregar").value = "";
});

function actualizarOrden(){

    const bloques =
    document.querySelectorAll('.bloque');

    bloques.forEach((bloque, index) => {

        // INPUT (ORDEN)
        const ordenInput =
        bloque.querySelector('.ordenInput');

        ordenInput.value = index;

        ordenInput.name =
        `elementos[${index}][orden]`;

        // INPUT
        const tipoInput =
        bloque.querySelector(
        'input[name*="[tipo]"]');

        tipoInput.name =
        `elementos[${index}][tipo]`;

        // CONTENIDO
        const contenido =
        bloque.querySelector(
        'input[name*="[contenido]"], textarea[name*="[contenido]"]');

        if(contenido){

            contenido.name =
            `elementos[${index}][contenido]`;

        }

        // IMAGEN
        const imagen =
        bloque.querySelector(
        'input[type="file"]');

        if(imagen){

            imagen.name =
            `imagenes[${index}]`;

        }

    });

}

function subirElemento(actElement){
    const actual = actElement.parentElement;
    const anterior = actual.previousElementSibling;

    if(anterior){
        actual.parentNode.insertBefore(actual, anterior);
        actualizarOrden();
    }
}

function bajarElemento(actElement){
    const actual = actElement.parentElement;
    const siguiente = actual.nextElementSibling;

    if(siguiente){
        actual.parentNode.insertBefore(siguiente, actual);
        actualizarOrden();
    }
}

function eliminarElemento(btn){

    btn.parentElement.remove();
    actualizarOrden();

}