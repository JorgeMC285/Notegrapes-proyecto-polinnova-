<!DOCTYPE html>
<?php
    session_start();
    require_once('phpFunc/conexion.php');
    require_once('phpFunc/regis.php');
    require_once('phpFunc/verif.php');
    

// + Verificar sesión iniciada  
    if(!isset($_SESSION['username']) || !isset($_SESSION['login'])){
        header('Location: index.html');
        exit();
    }
    $id = $_SESSION['id'];
    $nom = $_SESSION['username'];
    $lpId = $_SESSION['latestProyect'] ?? null;


// + Crear Proyecto
    if(isset($_POST['crearProyecto'])){
    // 1- Verificar datos
        $uId = $id;
        $tit = $_POST['tit'];
        $des = $_POST['des'];

        $resEP = verificarProyecto($uId, $tit, $conect);
        if($resEP){

    // 2- Registrar Proyecto
            $resRP = registrarProyecto($conect, $tit, $des, $uId);
            if($resRP){
                echo "<script>alert('Proyecto creado exitosamente');</script>";

                $resE = encontrarProyectoReciente($conect, $uId, "MAX(id)");
                if($resE){
    // 3- Redirigir al proyecto creado
                    $_SESSION['latestProyect'] = $resE;
                    $lpId = $_SESSION['latestProyect'];
                    echo "<script>window.location.href = 'contProyect.php?id=' + " . json_encode($lpId) . "; </script>";
                    exit();
                }
                echo "<script>window.location.href = 'menuPrin.php';</script>";
                exit();
            }
        }else{
            echo "<script>alert('Ya tienes un proyecto nombrado igual. Escriba otro nombre');</script>";
        }
    }

// + Cargar colores del proyecto
    $col = $_SESSION['color'];
?>
<html lang="es" class="<?php echo $col; ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/colors.css">
        <link rel="stylesheet" href="css/forms.css">
        <link rel="stylesheet" href="css/general.css">
        <link rel="stylesheet" href="css/design.css">
        <script src= "jscript/buttonsAct.js"></script>
        <link rel="icon" type="image/png" sizes="32x32" href="images/icon1.png">
        <title>Crear Proyecto</title>
    </head>
    <section class="patUp">
        <script src="jscript/buttonColors.js" defer></script>
        <body class="bodyPrin">
            <main id="mainPrin">
                <section class="mainCont">
                    <aside class="mainAsid">
                        <div id="asidCont">
                            <section class="logoCuen">
                                <a href="menuPrin.php">
                                    <p class="logText">Ir al menu</p>
                                    <img src="images/regresar.png" alt="Cuenta"> 
                                </a>
                            </section>
                            <div class="lin">
                              <hr class="homHr">   
                            </div>
                            <section class="logoCuen">
                                <a href="optsUsuario.php">
                                    <p class="logText"><?php echo $nom; ?></p>
                                    <img src="images/Cuenta.png" alt="Cuenta">
                                </a>     
                            </section>

                            <?php if(isset($_SESSION['latestProyect']) && $lpId != null){?>
                                
                                <div class="lin">
                                    <hr class="homHr">   
                                </div>
                            
                                <section class="logoCuen">
                                    <a href="listProyect.php">
                                        <p class="logText">Mis proyectos</p>
                                        <img src="images/Proyectos.png" alt="Cuenta"> 
                                    </a>
                                </section>

                                <div class="lin">
                                    <hr class="homHr">   
                                </div>

                                <section class="logoCuen">
                                    <a href="contProyect.php?id=<?php echo $_SESSION['latestProyect']; ?>">
                                        <p class="logText">Proyecto reciente</p>
                                        <img src="images/ReciProyecto.png" alt="Cuenta"> 
                                    </a>
                                </section>
                            <?php } ?>
                        </div>
                    </aside>
                    <section id="mainHH">
                        <section class="mainHom mainOpts mainEdit">
                            <section class="contOpts infoCont">
                                <section class="contInfo formsInfo">
                                    <section class="contChUser contFormUser">
                                        <form action="crearProyect.php" method="post">
                                        <!-- TITULO -->
                                            <div class="titleForm">           
                                                <h5 class="textWhite">Crear Proyecto:</h5>
                                                <hr>
                                            </div>
                                        <!--DATOS-->
                                            <div class="datForm">
                                                <label for="titulo">*Titulo del proyecto:</label>
                                                <br>
                                                <input class="input" type="text" id="titulo" name="tit" maxlength="100" placeholder="Ingrese el título del proyecto" value="<?php echo $tit ?? ''; ?>" required>
                                                <br>
                                                <label for="descripcion">Descripción del proyecto:</label>
                                                <br>
                                                <textarea id="descripcion" class="input textarea" name="des" maxlength="255" placeholder="Ingrese la descripción del proyecto (Opcional)"><?php echo $des ?? ''; ?></textarea>
                                                <br>
                                            </div>
                                        <!--BOTONES-->
                                            <div class="buttonForm">
                                                <button class="submit" type="reset">Limpiar</button>
                                                <button name="crearProyecto" type="submit" class="submit">Crear Proyecto</button>
                                            </div>
                                        </form>
                                    </section>
                                </section>
                            </section>
                        </section>
                    </section>
                </section>
            </main>
        </body>
    </section>
</html>