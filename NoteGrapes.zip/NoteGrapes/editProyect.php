<!DOCTYPE html>
<?php 
    session_start();
    require_once('phpFunc/conexion.php');
    require_once('phpFunc/verif.php');
    require_once('phpFunc/camb.php');
    
// + Verificar sesión iniciada    
    if(!isset($_SESSION['username']) || !isset($_SESSION['login'])){
        header('Location: index.html');
        exit();
    }
    $uId = $_SESSION['id'];
    $nom = $_SESSION['username'];

// + Verificar el id enviado por el link del proyecto a editar.
    $lpId = $_GET['id'] ?? $_SESSION['latestProyect'] ?? null;

    // Verificar si realmente existe un id.
    if($lpId === null){
        header('Location: menuPrin.php');
        exit();
    }

    // Guardar el último proyecto abierto en sesión.
    $_SESSION['latestProyect'] = $lpId;

// + Obtener datos de la base de datos del proyecto
    $resP = encontrarProyecto("id", $lpId, $conect);
    if(!$resP){
        echo "<script>alert('No se encontró el proyecto.');
                 window.location.href = 'menuPrin.php';</script>";
    }
    $oldTit = $resP['titulo'];
    $oldDes = $resP['descripcion'];
//
// ++ FUNCIONES
//
// + Enviar cambios al proyecto
    if(isset($_POST['enviarCambios'])){
    // 1- Verificar datos
        $tit = $_POST['tit'] ?? '';
        $des = $_POST['des'] ?? '';
        if(empty(trim($_POST['tit']))){
            echo "<script>alert('Coloque un titulo al proyecto');</script>";
        }else{
    // 2- Verificar nombre del proyecto
            $resVP = verificarProyecto($uId, $tit , $conect);
            if(!$resVP){
                if($tit == $oldTit){
                    echo "<script>alert('Coloco el mismo nombre del proyecto, escriba otro nombre.');</script>";
                }else{
                    echo "<script>alert('El nombre del proyecto ya esta en uso, escriba otro nombre.');</script>";
                }
            }else{
    // 
                $resA = actualizarProyecto($conect, $tit, $des, $lpId);
                if($resA){
                    echo "<script>alert('Cambios realizados exitosamente!.');
                    window.location.href = 'contProyect.php?id=" . $lpId . "';</script>";
                }
            }
        }
    }



// + Cargar colores del proyecto
    $col = $_SESSION['color'];
?>

<html lang="es" class="<?php echo $col; ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/colors.css">
        <link rel="stylesheet" href="css/forms.css">
        <link rel="stylesheet" href="css/general.css">
        <link rel="stylesheet" href="css/design.css">
        <script src= "jscript/buttonsAct.js"></script>
        <link rel="icon" type="image/png" sizes="32x32" href="images/icon1.png">
        <title>Editar <?php echo $oldTit; ?></title>
    </head>
    <section class="patUp">
        <script src="jscript/buttonColors.js" defer></script>
        <body class="bodyPrin">
            <main id="mainPrin">
                <section class="mainCont">
                    <aside class="mainAsid">
                        <div id="asidCont">
                            <section class="logoCuen">
                                <a href="menuPrin.php">
                                    <p class="logText">Ir al menu</p>
                                    <img src="images/regresar.png" alt="Cuenta"> 
                                </a>
                            </section>
                            <div class="lin">
                              <hr class="homHr">   
                            </div>
                            <section class="logoCuen">
                                <a href="optsUsuario.php">
                                    <p class="logText"><?php echo $nom; ?></p>
                                    <img src="images/Cuenta.png" alt="Cuenta">
                                </a>     
                            </section>
                          
                            <div class="lin">
                                <hr class="homHr">   
                            </div>
                        
                            <section class="logoCuen">
                                <a href="listProyect.php">
                                    <p class="logText">Mis proyectos</p>
                                    <img src="images/Proyectos.png" alt="Cuenta"> 
                                </a>
                            </section>

                            <div class="lin">
                                <hr class="homHr">   
                            </div>

                            <section class="logoCuen">
                                <a href="contProyect.php?id=<?php echo $_SESSION['latestProyect']; ?>">
                                    <p class="logText">Proyecto reciente</p>
                                    <img src="images/ReciProyecto.png" alt="Cuenta"> 
                                </a>
                            </section>

                            <div class="lin">
                                <hr class="homHr">   
                            </div>

                            <section class="logoCuen">
                                <a href="crearProyect.php">
                                    <p class="logText">Crear Proyecto</p>
                                    <img src="images/CrearProyecto.png" alt="Cuenta"> 
                                </a>
                            </section>
                        </div>
                    </aside>
                    <section id="mainHH">
                        <section class="mainHom mainOpts mainEdit">
                            <section class="contOpts infoCont">
                                <section class="contInfo formsInfo">
                                    <section class="contChUser contFormUser">
                                        <form action="editProyect.php" method="POST" onsubmit="return confirm('¿Seguro que desea guardar los cambios realizados?');">
                                            <div class="titleForm">           
                                                <h5 class="textWhite">Editar Proyecto:</h5>
                                                <hr>
                                            </div>
                                            <div class="datForm">
                                                <label for="titulo">*Nuevo Titulo:</label>
                                                <br>
                                                <input class="input" type="text" id="titulo" name="tit" maxlength="100" placeholder="Ingrese el título del proyecto" value="<?php echo $tit ?? $oldTit; ?>" required>
                                                <br>
                                                <label for="descripcion">Nueva Descripción:</label>
                                                <br>
                                                <textarea class="input textarea" type="text" id="descripcion" name="des" maxlength="255" placeholder="Ingrese la descripción del proyecto (Opcional)"><?php echo $des ?? $oldDes; ?></textarea>
                                                <br>
                                            </div>
                                            <div class="buttonForm">
                                                <button class="submit" type="reset">Reestablecer</button>
                                                <button name="enviarCambios" type="submit" class="submit">Guardar cambios</button>
                                            </div>     
                                        </form>
                                    </section>
                                </section>
                            </section>
                        </section>
                    </section>
                </section>
            </main>  
        </body>
    </section>
</html>